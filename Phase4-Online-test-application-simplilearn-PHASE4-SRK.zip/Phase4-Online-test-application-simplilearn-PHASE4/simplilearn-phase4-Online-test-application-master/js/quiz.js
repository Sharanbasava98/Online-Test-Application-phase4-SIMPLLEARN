let quiz=[
    {
        question:"How are java web applications packaged?",
        option:[
            "1.jar",
            "2.war",
            "3.zip",
            "4.jar and war",
        ],
        answer:4,
    },
    {
        question:"How can we take input text from user in HTML page?",
        option:[
            "1.input tag",
            "2.inoutBufferedReader tag",
            "3.meta tag",
            "4.scanner tag",
            
        ],
        answer:1,
    },
    {
        question:"Which of the below is not a javascript framework for UI?",
        option:[
            "1.Vaadin",
            "2.AngularJS",
            "3.KendoUI",
           "4.Springcore",   
        ],
        answer:4,
    },
    {
        question:"What type of protocol is HTTP?",
        option:[
            "1.stateless",
            "2.stateful",
            "3.transfer protocol",
            "4.information protocol",   
        ],
        answer:1,

    },
    {
        question:"Servlet are used to program which component in a web application",
        option:[
            "1.client",
            "2.server",
            "3.tomcat",
            "4.applet",   
        ],
        answer:2,
    }
]